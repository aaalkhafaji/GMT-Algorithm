#!/usr/bin/env python3
"""Reproducible algebraic and image-level checks for the revised manuscript.

The image tests are diagnostics of the stated transform identities and numerical
conditioning. They do not measure a new restoration or watermarking method.
"""
from __future__ import annotations

import csv
import hashlib
import itertools
import json
import os
import platform
import statistics
import time
from fractions import Fraction
from pathlib import Path

os.environ.setdefault("MPLCONFIGDIR", "/tmp/jmiv-mplconfig")
os.environ.setdefault("MPLBACKEND", "Agg")

import matplotlib.pyplot as plt
import numpy as np
import scipy
from PIL import Image, ImageOps
from scipy.ndimage import maximum_filter, minimum_filter


ROOT = Path(__file__).resolve().parent
ASSETS = ROOT / "assets"
RESULTS = ROOT / "results"
FIGURES = ROOT.parent / "figures"
RESULTS.mkdir(parents=True, exist_ok=True)
FIGURES.mkdir(parents=True, exist_ok=True)
SHAPES = [(32, 28), (64, 56), (128, 112)]  # (height, width), all rectangular
SEED = 20261006


def load_gray(path: Path, shape: tuple[int, int]) -> np.ndarray:
    """Load an included image, composite alpha on white, fit, and scale to [0,1]."""
    with Image.open(path) as source:
        rgba = source.convert("RGBA")
        white = Image.new("RGBA", rgba.size, (255, 255, 255, 255))
        gray = Image.alpha_composite(white, rgba).convert("L")
        fitted = ImageOps.fit(
            gray,
            (shape[1], shape[0]),
            method=Image.Resampling.LANCZOS,
            centering=(0.5, 0.5),
        )
        return np.asarray(fitted, dtype=np.float64) / 255.0


def synthetic_images(n: int, m: int) -> dict[str, np.ndarray]:
    yy, xx = np.mgrid[0:n, 0:m]
    x = xx / max(m - 1, 1)
    y = yy / max(n - 1, 1)
    impulse = np.zeros((n, m), dtype=np.float64)
    impulse[n // 2, m // 2] = 1.0
    checker = ((xx // max(m // 8, 1) + yy // max(n // 8, 1)) % 2).astype(float)
    gaussian = np.exp(-((x - 0.36) ** 2 / 0.025 + (y - 0.55) ** 2 / 0.08))
    edge = ((x > 0.57 + 0.12 * np.sin(6 * np.pi * y)) & (x < 0.83)).astype(float)
    texture = np.clip(
        0.5 + 0.25 * np.sin(2 * np.pi * (5 * x + 2 * y))
        + 0.25 * np.cos(2 * np.pi * (3 * y - x)),
        0.0,
        1.0,
    )
    return {
        "synthetic_impulse": impulse,
        "synthetic_checkerboard": checker,
        "synthetic_gaussian_edge": np.clip(0.55 * gaussian + 0.45 * edge, 0.0, 1.0),
        "synthetic_periodic_texture": texture,
    }


def dft2_dense(image: np.ndarray) -> np.ndarray:
    """Direct separable DFT with the same negative-exponent convention as fft2."""
    n, m = image.shape
    wn = np.exp(-2j * np.pi * np.outer(np.arange(n), np.arange(n)) / n)
    wm = np.exp(-2j * np.pi * np.outer(np.arange(m), np.arange(m)) / m)
    return wn @ image @ wm.T


def median_time(fn, repeats: int = 5) -> float:
    fn()
    samples = []
    for _ in range(repeats):
        t0 = time.perf_counter()
        fn()
        samples.append(time.perf_counter() - t0)
    return statistics.median(samples)


def psnr(reference: np.ndarray, estimate: np.ndarray) -> float:
    mse = float(np.mean((reference - estimate) ** 2))
    return float("inf") if mse == 0.0 else 10.0 * np.log10(1.0 / mse)


# Small exact polynomial toolkit. Coefficients are stored in ascending order.
Poly = list[Fraction]


def trim(p: Poly) -> Poly:
    q = list(p) or [Fraction(0)]
    while len(q) > 1 and q[-1] == 0:
        q.pop()
    return q


def padd(a: Poly, b: Poly) -> Poly:
    out = [Fraction(0)] * max(len(a), len(b))
    for i, c in enumerate(a):
        out[i] += c
    for i, c in enumerate(b):
        out[i] += c
    return trim(out)


def pneg(a: Poly) -> Poly:
    return [-c for c in a]


def psub(a: Poly, b: Poly) -> Poly:
    return padd(a, pneg(b))


def pmul(a: Poly, b: Poly) -> Poly:
    out = [Fraction(0)] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        for j, y in enumerate(b):
            out[i + j] += x * y
    return trim(out)


def pdivmod(a: Poly, b: Poly) -> tuple[Poly, Poly]:
    a, b = trim(a), trim(b)
    if b == [0]:
        raise ZeroDivisionError("zero polynomial")
    q = [Fraction(0)] * max(1, len(a) - len(b) + 1)
    r = list(a)
    while r != [0] and len(r) >= len(b):
        shift = len(r) - len(b)
        coeff = r[-1] / b[-1]
        q[shift] += coeff
        for j, c in enumerate(b):
            r[shift + j] -= coeff * c
        r = trim(r)
    return trim(q), trim(r)


def pmod(a: Poly, m: Poly) -> Poly:
    return pdivmod(a, m)[1]


def pscale(a: Poly, c: Fraction) -> Poly:
    return trim([c * x for x in a])


def pinverse_mod(a: Poly, m: Poly) -> Poly:
    old_r, r = trim(m), trim(a)
    old_s, s = [Fraction(0)], [Fraction(1)]
    while r != [0]:
        q, rem = pdivmod(old_r, r)
        old_r, r = r, rem
        old_s, s = s, psub(old_s, pmul(q, s))
    if len(old_r) != 1 or old_r[0] == 0:
        raise ArithmeticError("polynomials are not coprime")
    return pmod(pscale(old_s, 1 / old_r[0]), m)


def divisors(n: int) -> list[int]:
    return [d for d in range(1, n + 1) if n % d == 0]


def cyclotomic_polynomials(max_n: int) -> dict[int, Poly]:
    phi: dict[int, Poly] = {}
    for n in range(1, max_n + 1):
        xn_minus_one = [Fraction(-1)] + [Fraction(0)] * (n - 1) + [Fraction(1)]
        product: Poly = [Fraction(1)]
        for d in divisors(n):
            if d < n:
                product = pmul(product, phi[d])
        quotient, remainder = pdivmod(xn_minus_one, product)
        if remainder != [0] or quotient[-1] != 1:
            raise ArithmeticError(f"failed exact cyclotomic factorization for n={n}")
        phi[n] = quotient
    return phi


def exact_crt_trials() -> dict[str, object]:
    rng = np.random.default_rng(SEED + 11)
    phi = cyclotomic_polynomials(18)
    trials = 0
    max_denominator = 1
    for k in range(1, 19):
        modulus = [Fraction(-1)] + [Fraction(0)] * (k - 1) + [Fraction(1)]
        factors = [phi[d] for d in divisors(k)]
        idempotents: list[Poly] = []
        for factor in factors:
            cofactor, rem = pdivmod(modulus, factor)
            if rem != [0]:
                raise ArithmeticError("cyclotomic factor does not divide x^k-1")
            inverse = pinverse_mod(cofactor, factor)
            idempotents.append(pmod(pmul(cofactor, inverse), modulus))
        for _ in range(12):
            source = [Fraction(int(x)) for x in rng.integers(-20, 21, size=k)]
            residues = [pmod(source, factor) for factor in factors]
            recovered: Poly = [Fraction(0)]
            for residue, idem in zip(residues, idempotents):
                recovered = padd(recovered, pmul(residue, idem))
            recovered = pmod(recovered, modulus)
            if recovered != pmod(source, modulus):
                raise AssertionError(f"exact CRT reconstruction failed for k={k}")
            max_denominator = max(max_denominator, *(int(c.denominator) for c in recovered))
            trials += 1
    return {
        "status": "PASS",
        "exact_integer_vector_trials": trials,
        "lengths_tested": list(range(1, 19)),
        "maximum_reconstructed_denominator": max_denominator,
    }


def image_cases() -> dict[str, tuple[str, Path | None]]:
    return {
        "rabbit_original_figure": ("provided_image", ASSETS / "rabbit_from_original_figure.png"),
        "grace_hopper": ("photo_sample", ASSETS / "grace_hopper.jpg"),
        "blue_gift_icon": ("graphic_sample", ASSETS / "Minduka_Present_Blue_Pack.png"),
        "matplotlib_logo": ("graphic_sample", ASSETS / "logo2.png"),
    }


def make_report_figures() -> None:
    rabbit = load_gray(ASSETS / "rabbit_from_original_figure.png", (192, 192))
    dc = np.full_like(rabbit, float(np.mean(rabbit)))
    residual = rabbit - dc
    fig, ax = plt.subplots(1, 3, figsize=(10.2, 3.5), constrained_layout=True)
    ax[0].imshow(rabbit, cmap="gray", vmin=0, vmax=1)
    ax[0].set_title("Input image")
    ax[1].imshow(dc, cmap="gray", vmin=0, vmax=1)
    ax[1].set_title("DC projection (mean)")
    lim = float(np.max(np.abs(residual)))
    ax[2].imshow(residual, cmap="coolwarm", vmin=-lim, vmax=lim)
    ax[2].set_title("Zero-mean residual")
    for a in ax:
        a.axis("off")
    fig.savefig(FIGURES / "partition_dc_residual.png", dpi=220)
    plt.close(fig)

    # A compact visual record of the range of inputs used in the numerical
    # checks.  The DC component is deliberately shown separately from the
    # zero-mean remainder; no semantic labels are assigned to higher orbits.
    examples = [
        ("Provided rabbit crop", load_gray(ASSETS / "rabbit_from_original_figure.png", (128, 128))),
        ("Bundled photograph", load_gray(ASSETS / "grace_hopper.jpg", (128, 128))),
        ("Synthetic checkerboard", synthetic_images(128, 128)["synthetic_checkerboard"]),
        ("Synthetic edge/shape", synthetic_images(128, 128)["synthetic_gaussian_edge"]),
    ]
    fig, ax = plt.subplots(4, 3, figsize=(8.6, 9.2), constrained_layout=True)
    for row, (name, arr) in enumerate(examples):
        mean = float(np.mean(arr))
        residual = arr - mean
        lim = float(np.max(np.abs(residual)))
        ax[row, 0].imshow(arr, cmap="gray", vmin=0, vmax=1)
        ax[row, 0].set_ylabel(name, fontsize=9)
        ax[row, 1].imshow(np.full_like(arr, mean), cmap="gray", vmin=0, vmax=1)
        ax[row, 2].imshow(residual, cmap="coolwarm", vmin=-lim, vmax=lim)
        for col in range(3):
            ax[row, col].set_xticks([])
            ax[row, col].set_yticks([])
    for col, title in enumerate(["Input", "DC (mean)", "Zero-mean residual"]):
        ax[0, col].set_title(title, fontsize=10)
    fig.savefig(FIGURES / "image_decomposition_examples.png", dpi=220)
    plt.close(fig)

    blur_kernel = np.zeros_like(rabbit)
    blur_kernel[0, 0] = 1 / 9
    blur_kernel[0, 1] = 1 / 9
    blur_kernel[0, -1] = 1 / 9
    blur_kernel[1, 0] = 1 / 9
    blur_kernel[1, 1] = 1 / 9
    blur_kernel[1, -1] = 1 / 9
    blur_kernel[-1, 0] = 1 / 9
    blur_kernel[-1, 1] = 1 / 9
    blur_kernel[-1, -1] = 1 / 9
    linear = np.fft.ifft2(np.fft.fft2(rabbit) * np.fft.fft2(blur_kernel)).real
    dilated = maximum_filter(rabbit, size=3, mode="wrap")
    eroded = minimum_filter(rabbit, size=3, mode="wrap")
    fig, ax = plt.subplots(1, 4, figsize=(11.2, 3.3), constrained_layout=True)
    for a, arr, title in zip(
        ax,
        [rabbit, linear, dilated, eroded],
        ["Input", "Circular linear filter", "Flat dilation", "Flat erosion"],
    ):
        a.imshow(arr, cmap="gray", vmin=0, vmax=1)
        a.set_title(title)
        a.axis("off")
    fig.savefig(FIGURES / "linear_vs_morphology.png", dpi=220)
    plt.close(fig)

    phi = (1 + np.sqrt(5.0)) / 2
    psi = (1 - np.sqrt(5.0)) / 2
    t = np.linspace(0, 6, 1000)
    t_ode = np.linspace(0, 2.5, 500)
    fib_integer = np.array([0, 1, 1, 2, 3, 5, 8], dtype=float)
    n = np.arange(len(fib_integer))
    discrete_interp = (phi**t - np.abs(psi)**t * np.cos(np.pi * t)) / np.sqrt(5)
    ode_lambda_01 = (np.exp(phi * t_ode) - np.exp(psi * t_ode)) / np.sqrt(5)
    fig, ax = plt.subplots(1, 2, figsize=(10.2, 3.7), constrained_layout=True)
    ax[0].plot(t, discrete_interp, lw=2, label="real interpolation of $F_n$")
    ax[0].scatter(n, fib_integer, s=24, color="black", zorder=3, label="integer Fibonacci values")
    ax[0].set_xlim(0, 6)
    ax[0].set_ylim(-0.2, 9)
    ax[0].set_xlabel("$t$")
    ax[0].set_ylabel("value")
    ax[0].grid(alpha=0.25)
    ax[0].legend(fontsize=8)
    ax[1].plot(t_ode, ode_lambda_01, color="tab:orange", lw=2, label="ODE solution for $(U(0),U'(0))=(0,1)$")
    ax[1].plot(t_ode, np.exp(psi * t_ode), "--", color="tab:green", label="$e^{\\psi t}$ (positive, decaying)")
    ax[1].set_xlabel("$t$")
    ax[1].set_ylabel("value")
    ax[1].grid(alpha=0.25)
    ax[1].legend(fontsize=8)
    fig.savefig(FIGURES / "fibonacci_discrete_vs_ode.png", dpi=220)
    plt.close(fig)


def run_image_checks() -> list[dict[str, object]]:
    rng = np.random.default_rng(SEED)
    rows: list[dict[str, object]] = []
    source_files = image_cases()
    for height, width in SHAPES:
        cases: dict[str, tuple[str, np.ndarray]] = {
            name: (kind, load_gray(path, (height, width)))
            for name, (kind, path) in source_files.items()
        }
        cases.update({name: ("analytic_synthetic", arr) for name, arr in synthetic_images(height, width).items()})
        for index, (name, (kind, image)) in enumerate(cases.items()):
            dense_spec = dft2_dense(image)
            fft_spec = np.fft.fft2(image)
            roundtrip = np.fft.ifft2(fft_spec).real

            h = np.zeros_like(image)
            h[0, 0], h[1, 0], h[0, 1] = 0.7, 0.2, 0.1
            H = np.fft.fft2(h)
            observed = np.fft.ifft2(fft_spec * H).real
            recovered = np.fft.ifft2(np.fft.fft2(observed) / H).real

            hn = np.zeros_like(image)
            hn[0, 0], hn[0, 1] = 1.0, -0.999
            Hn = np.fft.fft2(hn)
            noisy_observed = np.fft.ifft2(fft_spec * Hn).real
            noise_sigma = 1e-4
            noise = rng.normal(0.0, noise_sigma, size=image.shape)
            recovered_noisy = np.fft.ifft2(np.fft.fft2(noisy_observed + noise) / Hn).real

            # This is a semantic comparison of distinct operations, not a shared-task score.
            average = np.zeros_like(image)
            for dy in (-1, 0, 1):
                for dx in (-1, 0, 1):
                    average[dy % height, dx % width] += 1 / 9
            linear_average = np.fft.ifft2(fft_spec * np.fft.fft2(average)).real
            dilation = maximum_filter(image, size=3, mode="wrap")
            erosion = minimum_filter(image, size=3, mode="wrap")
            morphology_gap = max(
                float(np.sqrt(np.mean((linear_average - dilation) ** 2))),
                float(np.sqrt(np.mean((linear_average - erosion) ** 2))),
            )

            rows.append(
                {
                    "image": name,
                    "input_class": kind,
                    "height": height,
                    "width": width,
                    "pixels": height * width,
                    "max_abs_dense_dft_vs_fft": float(np.max(np.abs(dense_spec - fft_spec))),
                    "roundtrip_rmse": float(np.sqrt(np.mean((roundtrip - image) ** 2))),
                    "roundtrip_psnr_db": psnr(image, roundtrip),
                    "stable_filter_min_spectrum": float(np.min(np.abs(H))),
                    "stable_deconvolution_rmse": float(np.sqrt(np.mean((recovered - image) ** 2))),
                    "near_singular_min_spectrum": float(np.min(np.abs(Hn))),
                    "near_singular_condition_ratio": float(np.max(np.abs(Hn)) / np.min(np.abs(Hn))),
                    "near_singular_noise_sigma": noise_sigma,
                    "near_singular_rmse": float(np.sqrt(np.mean((recovered_noisy - image) ** 2))),
                    "near_singular_psnr_db": psnr(image, recovered_noisy),
                    "linear_vs_morphology_rmse_gap": morphology_gap,
                    "fft_forward_median_ms": 1000 * median_time(lambda: np.fft.fft2(image)),
                    "dense_dft_median_ms": 1000 * median_time(lambda: dft2_dense(image)),
                    "tracked_array_payload_lower_bound_bytes": int(image.nbytes + fft_spec.nbytes + roundtrip.nbytes),
                }
            )
    return rows


def exact_join_defect_trials() -> dict[str, object]:
    """Check the exact lattice-join defect on small periodic kernels.

    Fractions are used throughout. For each kernel, every binary partition of
    its support is evaluated by the direct circular-convolution definition.
    We also exhaust all ternary-valued input pairs on the three-site example.
    """
    cases = [
        ("translated_impulse", (1, 4), {(0, 2): Fraction(1)}),
        ("two_site_average", (1, 2), {(0, 0): Fraction(1, 2), (0, 1): Fraction(1, 2)}),
        ("three_tap_7_2_1", (1, 3), {(0, 0): Fraction(7, 10), (0, 1): Fraction(2, 10), (0, 2): Fraction(1, 10)}),
        ("uniform_3_by_3", (3, 3), {(r, s): Fraction(1, 9) for r in range(3) for s in range(3)}),
    ]
    results = []
    for name, shape, kernel in cases:
        n, m = shape

        def at_zero(image: list[list[int]]) -> Fraction:
            return sum(
                (weight * image[(-r) % n][(-s) % m] for (r, s), weight in kernel.items()),
                Fraction(0),
            )

        sites = list(kernel)
        formula_value = Fraction(0)
        direct_value = Fraction(0)
        for code in range(1 << len(sites)):
            part = {sites[i] for i in range(len(sites)) if (code >> i) & 1}
            mass = sum((kernel[p] for p in part), Fraction(0))
            formula_value = max(formula_value, min(mass, 1 - mass))

            f = [[0 for _ in range(m)] for _ in range(n)]
            g = [[0 for _ in range(m)] for _ in range(n)]
            for r, s in sites:
                pixel = ((-r) % n, (-s) % m)
                f[pixel[0]][pixel[1]] = int((r, s) in part)
                g[pixel[0]][pixel[1]] = 1 - f[pixel[0]][pixel[1]]
            joined = [[max(f[i][j], g[i][j]) for j in range(m)] for i in range(n)]
            observed = at_zero(joined) - max(at_zero(f), at_zero(g))
            direct_value = max(direct_value, observed)

        max_weight = max(kernel.values())
        results.append(
            {
                "name": name,
                "shape": list(shape),
                "support_size": len(kernel),
                "mass_outside_largest_tap": str(1 - max_weight),
                "defect_from_subset_formula": str(formula_value),
                "defect_from_direct_binary_convolution": str(direct_value),
                "formula_matches_direct": formula_value == direct_value,
            }
        )

    # Exhaust every pair on the three-site torus with values {0, 1/2, 1}.
    h = [Fraction(7, 10), Fraction(2, 10), Fraction(1, 10)]
    signals = list(itertools.product((Fraction(0), Fraction(1, 2), Fraction(1)), repeat=3))
    observed_gray = Fraction(0)
    for f in signals:
        for g in signals:
            for x in range(3):
                joined = tuple(max(f[i], g[i]) for i in range(3))
                c_join = sum((h[r] * joined[(x - r) % 3] for r in range(3)), Fraction(0))
                c_f = sum((h[r] * f[(x - r) % 3] for r in range(3)), Fraction(0))
                c_g = sum((h[r] * g[(x - r) % 3] for r in range(3)), Fraction(0))
                observed_gray = max(observed_gray, c_join - max(c_f, c_g))

    return {
        "binary_partition_cases": results,
        "ternary_grayscale_case": {
            "grid": "1x3 periodic",
            "kernel": ["7/10", "2/10", "1/10"],
            "ordered_input_pairs_checked": len(signals) ** 2,
            "levels": ["0", "1/2", "1"],
            "observed_max_defect": str(observed_gray),
            "theorem_value": "3/10",
            "matches_theorem": observed_gray == Fraction(3, 10),
        },
        "all_checks_pass": all(x["formula_matches_direct"] for x in results)
        and observed_gray == Fraction(3, 10),
    }


def save_rows(rows: list[dict[str, object]]) -> None:
    path = RESULTS / "image_validation.csv"
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def save_metadata(rows: list[dict[str, object]], exact: dict[str, object], join_defect: dict[str, object]) -> None:
    manifest = []
    for name, (kind, path) in image_cases().items():
        manifest.append(
            {
                "name": name,
                "class": kind,
                "file": path.name,
                "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            }
        )
    join_path = RESULTS / "join_defect_check.json"
    join_path.write_text(json.dumps(join_defect, indent=2) + "\n", encoding="utf-8")
    metadata = {
        "date_utc": "2026-10-06",
        "python": platform.python_version(),
        "numpy": np.__version__,
        "scipy": scipy.__version__,
        "pillow": Image.__version__,
        "matplotlib": plt.matplotlib.__version__,
        "random_seed": SEED,
        "rectangular_shapes_height_width": SHAPES,
        "rows": len(rows),
        "image_inputs": manifest,
        "exact_cyclotomic_crt_check": exact,
        "exact_join_defect_check": join_defect,
        "scope": "Identity, inverse-sensitivity, morphology-semantics, and implementation diagnostics; not a restoration-quality benchmark or watermark study.",
        "csv_sha256": hashlib.sha256((RESULTS / "image_validation.csv").read_bytes()).hexdigest(),
        "join_defect_check_sha256": hashlib.sha256(join_path.read_bytes()).hexdigest(),
    }
    (RESULTS / "run_metadata.json").write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")


def save_accuracy_figure(rows: list[dict[str, object]]) -> None:
    means = []
    max_errors = []
    sizes = []
    for shape in SHAPES:
        subset = [r for r in rows if (r["height"], r["width"]) == shape]
        sizes.append(shape[0] * shape[1])
        means.append(float(np.median([r["roundtrip_rmse"] for r in subset])))
        max_errors.append(float(max(r["max_abs_dense_dft_vs_fft"] for r in subset)))
    fig, ax = plt.subplots(figsize=(6.2, 3.8), constrained_layout=True)
    ax.loglog(sizes, means, "o-", label="median round-trip RMSE")
    ax.loglog(sizes, max_errors, "s--", label="maximum dense DFT/FFT discrepancy")
    ax.set_xlabel("number of pixels")
    ax.set_ylabel("absolute error")
    ax.grid(True, which="both", alpha=0.25)
    ax.legend(fontsize=8)
    fig.savefig(FIGURES / "numerical_error_summary.png", dpi=220)
    plt.close(fig)


def main() -> None:
    make_report_figures()
    exact = exact_crt_trials()
    join_defect = exact_join_defect_trials()
    rows = run_image_checks()
    save_rows(rows)
    save_metadata(rows, exact, join_defect)
    save_accuracy_figure(rows)
    print(json.dumps({"rows": len(rows), "exact_crt": exact, "exact_join_defect": join_defect}, indent=2))


if __name__ == "__main__":
    main()
